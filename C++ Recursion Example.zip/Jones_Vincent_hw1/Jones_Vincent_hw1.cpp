#include<iostream>
using namespace std;

int findSum(int a[], int size);

int main()
{
    int n;
    cout << "Please enter the size of the array: ";
    cin >> n;

    int *array = new int[n];
    cout << "Please enter the values of the array: " << endl;
    for(int i=0; i < n ;i++)
    {
        cin >> array[i];
    }

    cout << "The sum of the values in the array is " << findSum(array, n) << endl;

    return 0;
}

// Recursive function to find the sum of elements in an array
int findSum(int a[], int size)
{
    // Base case: if the size is 0, return 0
    if (size == 0) {
        return 0;
    }
    // Get sum of the array
    else
        return a[size - 1] + findSum(a, size - 1);
}
